extern int piMainFunc( int argc, const char **argv );

int main( int argc, char **argv )
{
    return piMainFunc( argc, argv );
}
