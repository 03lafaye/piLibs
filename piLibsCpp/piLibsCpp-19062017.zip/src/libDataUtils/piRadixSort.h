#pragma once

namespace piLibs {

// object, value

void piRadixSort2( unsigned int *source, unsigned int *temp, unsigned int n );
void piRadixSort4( unsigned int *source, unsigned int *temp, unsigned int n );

} // namespace piLibs
