#pragma once

#include "../piImage.h"

namespace piLibs {


int pcx_load( wchar_t *nombre, unsigned char *buffer, unsigned char *paleta );

} // namespace piLibs
