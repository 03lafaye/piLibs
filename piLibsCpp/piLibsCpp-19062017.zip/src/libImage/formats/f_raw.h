#ifndef _RAW_H_
#define _RAW_H_

#include "image.h"

int RAW_Load( IMAGE *bmp, const char *name );
int RAW_Save( IMAGE *bmp, const char *name );

#endif
