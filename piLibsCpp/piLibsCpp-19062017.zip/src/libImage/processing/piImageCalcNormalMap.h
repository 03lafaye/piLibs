#pragma once

#include "../piImage.h"

namespace piLibs {

int piImage_Normalmap( piImage *img, const piImage *src, float scale );

} // namespace piLibs