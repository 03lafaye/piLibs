#pragma once

#include "../piImage.h"

namespace piLibs {

bool piImage_CanvasResize(piImage *image, unsigned int newxres, unsigned int newyres, void *color);

} // namespace piLibs