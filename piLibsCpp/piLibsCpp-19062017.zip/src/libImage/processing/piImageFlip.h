#pragma once

#include "../piImage.h"

namespace piLibs {

bool piImage_Flip(piImage *spr);

} // namespace piLibs