#pragma once

#include "../piImage.h"

namespace piLibs {

bool piImage_Invert(piImage *dst, const piImage *src, float amount);

} // namespace piLibs