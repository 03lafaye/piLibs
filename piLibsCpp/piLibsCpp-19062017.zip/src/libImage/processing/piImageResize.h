#pragma once

#include "../piImage.h"

namespace piLibs {

int piImage_Resize( piImage *img, int xres, int yres );

} // namespace piLibs