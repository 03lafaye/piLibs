#pragma once

#define STID  0
#define POSID 0
#define NORID 1
