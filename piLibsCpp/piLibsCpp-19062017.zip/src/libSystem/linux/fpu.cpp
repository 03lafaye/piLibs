
void FPU_SetMode_Floor( void )
{
}

void FPU_SetMode_Ceil( void )
{
}

